//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by ShapeDrawer.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SHAPE_DRAWER_DIALOG         102
#define IDR_MAINFRAME                   128
#define IDR_TOOLBAR1                    130
#define IDR_MENU1                       132
#define IDR_TOOLBAR2                    134
#define IDB_BITMAP1                     135
#define ID_OPTIONS_NEWSHAPE             32772
#define ID_OPTIONS_SHAPELIST            32773
#define ID_NEWSHAPE_CIRCLE              32774
#define ID_NEWSHAPE_TRIANGLE            32775
#define ID_NEWSHAPE_RECTANGLE           32776
#define ID_NEWSHAPE_POLYGON             32777
#define ID_OPTIONS_EXIT                 32778
#define ID_EDIT_UNDO32779               32779
#define ID_EDIT_REDO32780               32780
#define ID_OPTIONS_EXIT32781            32781
#define ID_NEWSHAPE_POLYGON32782        32782
#define ID_NEWSHAPE_LINE                32783
#define ID_NEWSHAPE_LINE1               32784
#define ID_RESET_REST                   32785
#define ID_COLOR_BLACK                  32786
#define ID_COLOR_WHITE                  32787
#define ID_COLOR_RED                    32788
#define ID_COLOR_GREEN                  32789
#define ID_COLOR_BLUE                   32790
#define ID_COLOR_YELLOW                 32791
#define ID_COLOR_CYAN                   32792
#define ID_COLOR_MAGNETA                32793
#define ID_OPTIONS_SAVE                 32794
#define ID_OPTIONS_LOAD                 32795
#define ID_OPTIONS_SELECTSHAPE          32796
#define ID_EDIT_BRINGTOFRONT            32797
#define ID_EDIT_DELETE                  32798
#define ID_OPTIONS_INVALIDATE           32799
#define ID_COLOR_SELECTCOLOR            32800
#define ID_EDIT_COPY32801               32801
#define ID_EDIT_PASTE32802              32802
#define ID_BUTTON32803                  32803
#define ID_BUTTON32805                  32805
#define ID_BUTTON32808                  32808
#define ID_COLOR_BACKGROUNDCOLOR        32809

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32810
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
